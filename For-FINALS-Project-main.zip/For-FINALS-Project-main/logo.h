#ifndef LOGO_H
#define LOGO_H
void logo(void);
#endif /* LOGO_H */

