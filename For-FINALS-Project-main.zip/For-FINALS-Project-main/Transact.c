#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define ACCOUNTS_FILE "database.txt" // File path for storing account data
#define MAX_USERNAME_LENGTH 100
#define MAX_PASSCODE_LENGTH 100

char fileUsername[MAX_USERNAME_LENGTH + 1];
char filePasscode[MAX_PASSCODE_LENGTH + 1];
float money;

// Function to read the money from the file
float get_money_fromFile(char *username, char *passcode)
{
    FILE *file = fopen(ACCOUNTS_FILE, "r"); // Open the file in read mode
    if (file == NULL)
    {
        printf("Error in accessing details!\n");
        return -1;
    }

    while (fscanf(file, "%s %s %f", fileUsername, filePasscode, &money) == 3)
    {
        if (strcmp(username, fileUsername) == 0 && strcmp(passcode, filePasscode) == 0)
        {
            fclose(file); // Close the file
            return money; // Returns money value
        }
    }

    fclose(file); // Close the file
    return -1; // Return a negative value to indicate username/passcode not found
}

float getMoney_byUsername(const char *username) 
{
    FILE *file = fopen(ACCOUNTS_FILE, "r"); // Read mode 
    if (file == NULL) 
	{
        printf("Error in accessing details!\n");
        return -1;
    }

    char fileUsername[MAX_USERNAME_LENGTH + 1]; // Variables so that it can just read from the file (temp)
    char filePasscode[MAX_PASSCODE_LENGTH + 1];
    float money;

    while (fscanf(file, "%s %s %f", fileUsername, filePasscode, &money) == 3)
	{
        if (strcmp(username, fileUsername) == 0)
		{
            fclose(file); // Close the file
            return money; // Return money value
        }
    }

    fclose(file); // Close the file
    return -1; // Return a negative value to indicate username not found
}

void updateMoney(const char *username, const char *passcode, float newMoney, int *status)
{
    FILE *file = fopen(ACCOUNTS_FILE, "r");
    if (file == NULL)
    {
        printf("Error opening file for reading.\n");
        return;
    }

    // Read the entire file into memory
    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    fseek(file, 0, SEEK_SET);

    char *fileContent = (char *)malloc(fileSize + 1);
    fread(fileContent, 1, fileSize, file);
    fclose(file);
    fileContent[fileSize] = '\0';

    // Open the file for writing
    file = fopen(ACCOUNTS_FILE, "w");
    if (file == NULL)
    {
        printf("Error opening file for writing.\n");
        free(fileContent);
        return;
    }

    // Variables for scanning the file content
    char *line = strtok(fileContent, "\n");
    int found = 0;

    while (line != NULL)
    {
        sscanf(line, "%s %s %f", fileUsername, filePasscode, &money);
        if (strcmp(username, fileUsername) == 0 && (passcode == NULL || strcmp(passcode, filePasscode) == 0))
        {
            fprintf(file, "%s %s %.2f\n", fileUsername, filePasscode, newMoney);
            found = 1;
        }
        else
        {
            fprintf(file, "%s\n", line);
        }
        line = strtok(NULL, "\n");
    }

    fclose(file);
    free(fileContent);

    if (found)
    {
        printf("\n\n\t\t\t\t\tTransaction Successful!\n");
        *status = 1;
    }
    else
    {
        printf("\n\n\t\t\t\t\tAccount not found.\n");
    }
}


int verify_balance(float money, float amount)
{
    return money >= amount ? 1 : 0;
}

void deposit(char *username, char *passcode, int *loggedIn)
{
    float newMoney = 0;
    float depositAmount;
    int status = 0;
    char confVal;
    system("cls");
    logo();

    if (*loggedIn == 0)
    {
        login(username, passcode, loggedIn);
    }

    money = get_money_fromFile(username, passcode);

    if (*loggedIn == 1)
    {
        while (1)
        {
        back:
        	printf("\n\n\t\t\t\t\tUsername: %s", username);
        	printf("\n\t\t\t\t\tBalance: $%0.2f", money);
            printf("\n\n\t\t\t\t\tPlease enter amount of money you want to deposit:\n");
            printf("\n\t\t\t\t\tAmount: ");
            scanf("%f", &depositAmount);
            if (depositAmount > 100000)
            {
                system("cls");
                logo();
                printf("\n\n\t\t\t\t\tSorry. Deposit limit has been reached. Above 100k is not allowed.");
            }
            else
            {
                break;
            }
        }

        system("cls");
        logo();
        printf("\n\n\t\t\t\t\tDeposit Amount: %.2f", depositAmount);
        printf("\n\t\t\t\t\tPlease confirm transaction:\n");
        printf("\t\t\t\t\tYES - Press 1        CANCEL - Press 0\n");
        printf("\t\t\t\t\t: ");
        scanf(" %c", &confVal);

        system("cls");
        logo();

        if (confVal == '1')
        {
            newMoney = money + depositAmount;
            updateMoney(username, passcode, newMoney, &status);
        }
        else if (confVal == '0')
        {
            goto back;
        }

        if (status == 1)
        {
            printf("\n\t\t\t\t\tBalance: %.2f", newMoney);
            *loggedIn = 0;
        }
    }
    else
    {
        system("cls");
        logo();
        printf("\n\n\t\t\t\t\tLogin Failed. Returning to Main Screen!");
        *loggedIn = 0;
    }
}

void withdraw(char *username, char *passcode, int *loggedIn)
{
    float newMoney = 0;
    float amount = 0;
    char choice_amount;
    int status = 0; // 0 means not yet success

    system("cls"); // Clears the screen
    logo(); // Calls logo function

    if (*loggedIn == 0)
    {
        login(username, passcode, loggedIn); // Calls the login function
    }

    money = get_money_fromFile(username, passcode); // Gets the username and passcode to find its balance

    if (*loggedIn == 1)
    {
    	Home:
        printf("\n\n\t\t\t\t\tUsername: %s", username);
        printf("\n\t\t\t\t\tBalance: $%0.2f", money);
        printf("\n\n\t\t\t\t\tSelect Withdrawal Amount:");
        printf("\n\t\t\t\t\t1: $500");
        printf("\n\t\t\t\t\t2: $1000");
        printf("\n\t\t\t\t\t3: $2000");
        printf("\n\t\t\t\t\t4: $5000");
        printf("\n\t\t\t\t\t5: $10,000");
        printf("\n\t\t\t\t\t6: Input Amount");
        printf("\n\t\t\t\t\tSelection: ");
        scanf(" %c", &choice_amount);

        // Check to see if balance is sufficient
        system("cls");
        logo();

        switch (choice_amount)
        {
            case '1': amount = 500; break;
            case '2': amount = 1000; break;
            case '3': amount = 2000; break;
            case '4': amount = 5000; break;
            case '5': amount = 10000; break;
            case '6':
                printf("\n\n\t\t\t\t\tEnter Amount: ");
                scanf("%f", &amount);
                break;
        }

        // Calculation and Money update Block
        if (verify_balance(money, amount) == 0)
        {
            printf("\n\t\t\t\t\tInsufficient Balance!!");
            printf("\n\t\t\t\t\tLogging Out!\n");
            *loggedIn = 0;
        }
        else
        {
        		char choice_confirm;
        		printf("\n\n\t\t\t\t\tWithdraw Amount: $%.2f", amount);
       			printf("\n\t\t\t\t\tPlease confirm transaction:\n");
        		printf("\t\t\t\t\tYES - Press 1        CANCEL - Press 0\n");
        		printf("\t\t\t\t\t: ");
        			scanf(" %c", &choice_confirm);
        		
        		switch(choice_confirm)
        		{
        			case '1':
        				{
        					newMoney = money - amount;
            				newMoney = roundf(newMoney * 100.0) / 100.0; // Round to two decimal places
            				updateMoney(username, passcode, newMoney, &status);
            				break;
						}
					case '0':
						{
							system("cls");
							logo();
							printf("\n\t\t\t\t\tTransaction Cancelled!");
							sleep(1);
							goto Home;
							break;
						}
					default:
						system("cls");
						logo();
						printf("\n\n\t\t\t\t\tInvalid Choice, Please try again!");
						goto Home;
				}
			}
            

            if (status == 1)
            {
            	fflush(stdin);
            	system("cls");
            	logo();
            	printf("\n\n\t\t\t\t\tUsername: %s", username);
                printf("\n\t\t\t\t\tBalance: %.2f", newMoney);
                printf("\n\t\t\t\t\tPress Enter to continue!");
                getchar();
                *loggedIn = 0;
            }
        }
    	else
    	{
	        system("cls");
	        logo();
	        printf("\n\n\t\t\t\t\tLogin Failed. Returning to Main Screen!");
	        *loggedIn = 0;
    	}
}

void money_transfer(char *username, char *passcode, int *loggedIn)
{
    float mainAcctMoney, recipientAcctMoney, amount;
    char recipient_username[MAX_USERNAME_LENGTH + 1];
    int status = 0;

    system("cls");
    logo();

    if (*loggedIn == 0)
    {
        login(username, passcode, loggedIn);
    }

    if (*loggedIn == 1)
    {
        mainAcctMoney = get_money_fromFile(username, passcode); // Retrieve the main account balance

        if (mainAcctMoney == -1) // Check if Account is not found
        {
            system("cls");
            logo();
            printf("\n\n\t\t\t\t\tAccount does not exist!\n");
            *loggedIn = 0;
            return;
        }

        // Recipient Block
        system("cls");
        logo();
        while(1)
        {
            printf("\n\n\t\t\t\t\tUsername: %s", username);
            printf("\n\t\t\t\t\tCurrent Balance: %0.2f", mainAcctMoney);
            printf("\n\t\t\t\t\tEnter Recipient Account Name: ");
            scanf("%s", recipient_username);
            recipientAcctMoney = getMoney_byUsername(recipient_username); // Retrieve Recipient Account balance
            if (recipientAcctMoney == -1)
            {
                system("cls");
                logo();
                printf("\n\t\t\t\t\tRecipient Account not Found!\n");
            }
            else
                break;
        }

        // Funds Block
        printf("\n\n\t\t\t\t\tEnter Amount to transfer: ");
        scanf("%f", &amount);

        if (verify_balance(mainAcctMoney, amount) == 0)
        {
            system("cls");
            logo();
            printf("\n\n\t\t\t\t\tInsufficient Balance!!");
            printf("\n\t\t\t\t\tLogging Out!");
            *loggedIn = 0;
            return;
        }

        // Deduction of money from main account
        mainAcctMoney -= amount;
        mainAcctMoney = roundf(mainAcctMoney * 100.0) / 100.0; // Round to two decimal places
        updateMoney(username, passcode, mainAcctMoney, &status);

        if (status == 1)
        {
            // Addition of amount to recipient's account
            recipientAcctMoney += amount;
            recipientAcctMoney = roundf(recipientAcctMoney * 100.0) / 100.0; // Round to two decimal places
            updateMoney(recipient_username, NULL, recipientAcctMoney, &status); // Use NULL for passcode

            if (status == 1)
            {
                system("cls");
                logo();
                printf("\n\n\t\t\t\t\tTransfer Successful!");
                printf("\n\t\t\t\t\tUsername: %s", username);
                printf("\n\t\t\t\t\tCurrent Balance: %.2f", mainAcctMoney);
            }
            else
            {
                // Rollback in case of failure to update recipient's account
                mainAcctMoney += amount;
                updateMoney(username, passcode, mainAcctMoney, &status);
                system("cls");
                logo();
                printf("\n\n\t\t\t\t\tTransfer Failed. Rolling back the transaction.");
            }
        }
        else
        {
            system("cls");
            logo();
            printf("\n\n\t\t\t\t\tTransfer Failed. Returning to Main Screen!\n");
        }
        *loggedIn = 0;
    }
}
