#include <stdio.h>
#include <windows.h>
#include "logo.h"
#include "AcctManage.h"
#include "Transact.h"

int main() 
{
    int loggedIn = 0; // No one is logged in yet
    char choice_1, choice_2, choice_term, choice_transact; // Initialization of variables or declaration
    char username[MAX_USERNAME_LENGTH + 1]; // +1 for null terminator
    char password[MAX_PASSCODE_LENGTH + 1]; // +1 for null terminator
    float money = 0;
	logo();
    while (1) 
	{
		Main:
        // Selection
        printf("\n\n\t\t\t\t\t        MAIN SCREEN\n\n");
        printf("\n\t\t\t\t\t1. Account Management");
        printf("\n\t\t\t\t\t2. Transaction Processing");
        printf("\n\t\t\t\t\t3. Other Services");
        printf("\n\t\t\t\t\t4. Exit");
        printf("\n\n\t\t\t\t\tSelection: ");
        scanf(" %c", &choice_1);
		
        switch(choice_1) 
		{
            case '1':
            {
                system("cls"); // Clear Previous Screen
                logo(); // Logo "BANK" Printing function
				 	printf("\n\n\t\t\t\t\t\tAccount Management\n\n");
			        printf("\n\t\t\t\t\t1. Account Creation");
			        printf("\n\t\t\t\t\t2. Login Account");
			        printf("\n\t\t\t\t\t3. Account Termination"); 
			        printf("\n\t\t\t\t\t4. Back");
			        printf("\n\t\t\t\t\t5. Logout");
			        printf("\n\n\t\t\t\t\tSelection: ");
			        scanf(" %c", &choice_2);
				switch(choice_2) //Another One 
				{
					case '1':
						{
							if (loggedIn == 0) 
							{
			                    accountCreation();
			                } 
							else 
							{
			                    printf("\nAlready logged in!\nPress Enter to continue...");
			                    getchar();
			                    fflush(stdin);    
	                		}		
						break;	
						}
					case '2':
						{
							system("cls");
							logo();
							if (loggedIn == 0) // If no account is logged in
							{
								login(username, password, &loggedIn);
							}
							else
							{
								printf("\n\n\t\t\t\t\tAccount has been logged in already.\n");
							}
							break;
						}
					case'3':
						{	
							system("cls");
							logo();
							if (loggedIn == 1)
							{
								printf("\n\n\t\t\t\t\t1 > YES");
								printf("\n\t\t\t\t\t2 > NO");
								printf("\n\t\t\t\t\tAre you sure to terminate your account?: ");
									scanf("%d", &choice_term);
								if (choice_term == 1)
								{
									terminateAccount(username, password); //Function to terminate passing the current logged in account
								}
								else
								{
									system("cls");
									logo();
									printf("\n\n\t\t\t\t  Account Logged out."); //Automatic Log out after this
									break;
								}
							}
							else //Belongs to first if
							{
								printf("\n\t\t\t\t\tYou need to login first!\n");
							}
							break;
						}
					case '4':
						{
							system("cls");
							logo();
							goto Main;
							break;
						}
					case '5':
						{
							system("cls");
							logo();
								if (loggedIn == 1)
								{
									loggedIn = 0;
									printf("\n\n\t\t\t\t\t    Account Logged Out!");
								}
								else
								{
									printf("\n\n\t\t\t\t\tNo account has been logged in!");
								}
							break;
						}
					default:
						system("cls");
						logo();
						printf("\n\n\t\t\t\tSorry. Invalid Choice :)!!!!");
						break;
				}//Belongs to choice_2
				
            break;//Belongs to choice_1
            } 
            
            case '2': //Belongs to choice_1 (Transaction Processing)
                {
                	if (check_file_exists(ACCOUNTS_FILE) == 1)
                	{
						// Transaction processing functionality will be added here
						system("cls");
						logo();
	                	printf("\n\n\t\t\t\t\t  Transaction Processing");
	                	printf("\n\n\t\t\t\t\t1. Withdraw");
	                	printf("\n\t\t\t\t\t2. Deposit");
	                	printf("\n\t\t\t\t\t3. Money Transfer");
	                	printf("\n\t\t\t\t\t4. Back");
	                	printf("\n\n\t\t\t\t\tSelection: ");
	                		scanf(" %c", &choice_transact);
	                	switch(choice_transact)
	                	{
	                		case '1':
	                			{
	                				withdraw(username, password, &loggedIn);
	                				sleep(2);
	                				system("cls");
	                				logo();
	                				break;
								}
							case '2':
								{
									deposit(username, password, &loggedIn);
									sleep(2);
									system("cls");
									logo();
									break;
								}
							case '3':
								{
									money_transfer(username, password, &loggedIn);
									sleep(2);
									system("cls");
									logo();
									break;
								}
							case '4':
								{
									system("cls");
									logo();
									printf("\n\n\t\t\t\t\t   Returned to Main Menu!");
									break;
								}
						}
					}
					else
					{
						system("cls");
						logo();
						printf("\n\n\t\t\t\t\tNo Accounts Registered!");
						goto Main;
					}
					break;
            	}
            case '3': //Belongs to choice_1 (Other Services
               {
               	/* Additional Functions will be here */
               	//Transaction History Function here
               	break;
			   }
                
            case '4': //Belongs to choice_1 (Exiting Case)
            	{
            		system("cls");
            		logo();
            		printf("\n\t\t\t\t\tThank you for using TaGam Banking!!\n");
                	printf("\n\t\t\t\t\tExiting...\n");
                	return 0;
            	}
            default: //Belongs to choice_1 (If input does not match the selection)
            	system("cls");
            	logo();
                printf("\n\t\t\t\t\tSorry. Invalid Choice :(\n\n");
                break;
        }
    }
}
