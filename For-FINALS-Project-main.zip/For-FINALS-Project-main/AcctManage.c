#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "logo.h"
#include "AcctManage.h"

#define MAX_ACCOUNTS 100 // Maximum number of accounts
#define MAX_USERNAME_LENGTH 11
#define MAX_PASSCODE_LENGTH 9
#define ACCOUNTS_FILE "database.txt" // File path for storing account data

// Function to check if an account exists
int accountExists(const char *username, const char *passcode) //username and passcode points to the username and passcode inputted 
{
    FILE *file = fopen(ACCOUNTS_FILE, "r"); //File syntax to open text file in read mode
    if (file == NULL) //If file cannot be read or does not exist
	{
        printf("\n\n\t\t\t\t\tError!\n\t\t\t\t\tReturning to Main scree,.\n");
        return 0;
    }

    char fileUsername[MAX_USERNAME_LENGTH];
    char filePasscode[MAX_PASSCODE_LENGTH];
    float money;

    while (fscanf(file, "%s %s %f", fileUsername, filePasscode, &money) != EOF)  //EOF means end of file, loop until fscanf returns EOF
	{
        if (strcmp(username, fileUsername) == 0 && strcmp(passcode, filePasscode) == 0) //Checks to see if the inputted username and pasocde matches
		{
            fclose(file); //Closes the file 
            return 1; // Account found
        }
    }

    fclose(file); //Closes the file 
    return 0; // Account not found
}

// Function to login to an account
void login(char *username, char *password, int *loggedIn) 
{
    char loginusername[MAX_USERNAME_LENGTH];
    char loginpasscode[MAX_PASSCODE_LENGTH];

    printf("\n\n\t\t\tEnter username: ");
    scanf("%s", loginusername);
    printf("\t\t\tEnter passcode: ");
    scanf("%s", loginpasscode);

    if (accountExists(loginusername, loginpasscode))  //Checks if account does exist using the function passing the inputs
	{
        strcpy(username, loginusername); //Copies the input to the username and passcode 
        strcpy(password, loginpasscode);
        *loggedIn = 1;
        system("cls");
        logo();
        printf("\n\t\t\t\t\tAccount Logged in Successfully!\n");
    } 
	else 
	{
		system("cls");
		logo();
        printf("\n\t\t\t\tUsername or passcode does not exist or didn't match.\n\n");
    }
}

void accountCreation() 
{
    User *newUser = (User *)malloc(sizeof(User));
    if (newUser == NULL) 
	{
        printf("Memory allocation failed.\n");
        return;
    }
	fflush(stdin);
	system("cls");
	logo();
	while(1) //Username Loop
	{
	    printf("\n\n\t\t  Enter Account Username (No SPACES | Max = 10 characters!!): ");
	    scanf("%[^\n]", newUser->username);
	    	fflush(stdin);
	    	
	    	//Condition Blocks for error trapping
	    		if (strlen(newUser->username) > 10 || strlen(newUser->username) < 5)
	    		{
	    			system("cls");
	    			logo();
	    			printf("\n\t\t\t\t\tUsername is too long or too short. Try again!\n");
				}
				else if (strchr(newUser->username, ' ') != NULL)
				{
					system("cls");
	    			logo();
					printf("\n\t\t\t\t\tUsername contains spaces. Try again!\n");
				}
				else
					break;
				
	}
	
	while(1) //Passcode Loop
	{
    printf("\t\t  Enter Account 8-digit Passcode: ");
    	scanf("%[^\n]", newUser->passcode);
    		fflush(stdin);
	    		if (strlen(newUser->passcode) > 8 || strlen(newUser->passcode) < 3)
	    		{
	    			printf("\n\t\t\t\t\tPasscode is too long or too short :). Try again!\n");
				}
				else if (strchr(newUser->passcode, ' ') != NULL)
				{
					printf("\n\t\t\t\t\tPassword contains spaces. Try again!\n");
				}
				else
					break;
				
	}
    newUser->money = 1000; //Initializes to 1000 for simulation

    registerAccount(newUser->username, newUser->passcode, newUser->money); //Passes the pointer username and passcode to the function

    free(newUser); //frees newUser
}

void registerAccount(const char *username, const char *password, float money) 
{
    
    FILE *file = fopen("database.txt", "a"); // Open the file in append mode
    if (file != NULL) 
	{
        fprintf(file, "%s %s %0.2f\n", username, password, money); //Prints the inputted username and password into the file
        fclose(file); //Closes the file
        system("cls");
        logo();
        printf("\n\n\t\t\t\t\tAccount registered successfully!\n");
    } 
	else 
	{
        printf("\n\n\t\t\t\t\tFailed to open database file.\n");
    }
}

// Function to remove an account from the file
void removeAccountFromFile(const char *username, const char *passcode) 
{
    FILE *file = fopen(ACCOUNTS_FILE, "r"); //Opens the file for read mode
    if (file == NULL) 
    {
        printf("\n\n\t\t\t\t\tError opening file for reading.\n");
        return;
    }

    FILE *tempFile = fopen("temp.txt", "w"); //Opens the temp_file for write mode
    if (tempFile == NULL) 
    {
        printf("\n\n\t\t\t\t\tError opening temporary file.\n");
        fclose(file); //Closes the original file to prevent corruption
        return; //Return if error occurs
    }

    char fileUsername[MAX_USERNAME_LENGTH]; //Declaration of fileusername (temporary)
    char filePasscode[MAX_PASSCODE_LENGTH];//Declaration of filepasscode (temporary)
    float money;

    while (fscanf(file, "%s %s %f", fileUsername, filePasscode, &money) != EOF)  //EOF means end of file
    {
        if (strcmp(username, fileUsername) != 0 || strcmp(passcode, filePasscode) != 0) //Checks to see if the inputted username and pasocde doesatch
        {
            fprintf(tempFile, "%s %s %.2f\n", fileUsername, filePasscode, money); //Copies the accounts into the new file to erase the old one
        }
    }

    fclose(file);
    fclose(tempFile);//closes the tempfile

    // Remove the original file and rename the temporary file
    remove(ACCOUNTS_FILE);
    rename("temp.txt", ACCOUNTS_FILE);
	system("cls");
	logo();
    printf("\n\n\t\t\t\t\tAccount terminated successfully!\n");
}

// Function to terminate an account
void terminateAccount(const char *username, const char *passcode) 
{
    removeAccountFromFile(username, passcode); //Calls function and passing the username and passcode which points to the username and password
}
